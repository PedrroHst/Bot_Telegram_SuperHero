import json
import os
import time
import urllib.parse
import urllib.request
import urllib.error

# $env:TELEGRAM_BOT_TOKEN="8920923007:AAHRjyVybrQ6VGWdeLIy79E4-D1v7WmRwcc"
# $env:SUPERHERO_TOKEN="b3c6b2ca1fede5c8ea41c034b3c879c7"

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
SUPERHERO_TOKEN = os.getenv("SUPERHERO_TOKEN")

if not BOT_TOKEN:
    raise RuntimeError("Token do Telegram não configurado!")

if not SUPERHERO_TOKEN:
    raise RuntimeError("Token da Superhero API não configurado!")

TG = f"https://api.telegram.org/bot{BOT_TOKEN}"
HERO = f"https://superheroapi.com/api/{SUPERHERO_TOKEN}"

HEADERS = {
    "Content-Type": "application/json",
    "User-Agent": "MeuBotTelegram/1.0"
}


def chamar(url, dados=None, metodo="POST"):
    if dados is not None and metodo == "GET":
        params = urllib.parse.urlencode(dados)
        url = f"{url}?{params}"
        req = urllib.request.Request(
            url,
            headers=HEADERS,
            method="GET"
        )
    else:
        corpo = (
            json.dumps(dados).encode("utf-8")
            if dados is not None else None
        )

        req = urllib.request.Request(
            url,
            data=corpo,
            headers=HEADERS,
            method=metodo
        )

    try:
        with urllib.request.urlopen(req, timeout=40) as resposta:
            return json.loads(resposta.read().decode("utf-8"))

    except urllib.error.HTTPError as e:
        print("STATUS:", e.code)
        print("API:", urllib.parse.urlsplit(url).hostname)
        print("RESPOSTA:", e.read().decode("utf-8"))
        raise

    except urllib.error.URLError as e:
        print("HOST:", urllib.parse.urlsplit(url).hostname)
        print("DETALHE:", repr(e.reason))
        raise


def buscar(nome):
    url = f"{HERO}/search/{urllib.parse.quote(nome, safe='')}"
    r = chamar(url, metodo="GET")

    if r.get("response") == "success":
        resultados = r.get("results", [])
        return resultados[0] if resultados else None

    return None


def ficha(h):
    p = h["powerstats"]

    return (
        f"{h['name']}\n"
        f"Editora: {h['biography']['publisher']}\n\n"
        f"Inteligência: {p['intelligence']}\n"
        f"Força: {p['strength']}\n"
        f"Velocidade: {p['speed']}\n"
        f"Durabilidade: {p['durability']}\n"
        f"Poder: {p['power']}\n"
        f"Combate: {p['combat']}"
    )


def responder(chat_id, texto):
    texto = texto.strip()

    if texto.startswith("/start"):
        chamar(
            f"{TG}/sendMessage",
            {
                "chat_id": chat_id,
                "text": "Mande o nome de um herói (em inglês). Ex: batman"
            }
        )
        return

    heroi = buscar(texto)

    if not heroi:
        chamar(
            f"{TG}/sendMessage",
            {
                "chat_id": chat_id,
                "text": "Herói não encontrado ou nome inválido."
            }
        )
        return

    chamar(
        f"{TG}/sendPhoto",
        {
            "chat_id": chat_id,
            "photo": heroi["image"]["url"],
            "caption": ficha(heroi)
        }
    )


offset = 0

print("Bot rodando...")

while True:
    try:
        updates = chamar(
            f"{TG}/getUpdates",
            {
                "timeout": 30,
                "offset": offset
            },
            metodo="GET"
        ).get("result", [])

        for u in updates:
            offset = u["update_id"] + 1

            msg = u.get("message", {})

            if msg.get("text"):
                try:
                    responder(
                        msg["chat"]["id"],
                        msg["text"]
                    )
                except Exception as e:
                    print("Erro ao responder:", e)

    except Exception as e:
        print("Erro:", e)
        time.sleep(5)
